 <?php 
	include 'includes/connect.php';
	session_start();
   	
	
	$username = $_POST["username"];
	$_SESSION['team-id'] = $username;
    $password = $_POST["password"];
    $selectedeventid = $_POST["selectedevent"];
   	$_SESSION["event-id"] = $selectedeventid;

    $sql = "SELECT teamid, password, eventid, logincheck 
    FROM teams 
    WHERE teamid = $username AND password = '$password' AND eventid = $selectedeventid;";
	$result = $conn->query($sql);

	//printf("%d %s %d %d", $username, $password, $selectedeventid, $result);
	if ($result) {
		//echo "LogIn Successful";
		while($row = $result->fetch_assoc()) {
			if($row["logincheck"]==0) {
				$sqlupdate = "UPDATE teams SET logincheck=1 WHERE teamid=$username AND eventid=$selectedeventid";

				if ($conn->query($sqlupdate) === TRUE) {
    				//echo "Record updated successfully !";
    				?><META http-equiv="refresh" content="0.05;URL=test.php"><?php
				} 
				else {
					//echo "2";
    				//echo "Error updating record: " . $conn->error;
    				?><META http-equiv="refresh" content="3;URL=index.php"><?php
				}
			}
			else { //echo "3";
				//echo "Already logged in..session exists !";
				?><META http-equiv="refresh" content="3;URL=index.php"><?php
			}
		}
	}
	else {

		echo "LogIn unsuccessful !";
		?><META http-equiv="refresh" content="3;URL=index.php"><?php
	}

?>