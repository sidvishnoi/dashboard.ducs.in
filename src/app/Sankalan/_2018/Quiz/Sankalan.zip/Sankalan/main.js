
// function to update and move to next question
		function update_qid(str) {
		    
		        if (window.XMLHttpRequest) {
		            // code for IE7+, Firefox, Chrome, Opera, Safari
		            xmlhttp = new XMLHttpRequest();
		        } else {
		            // code for IE6, IE5
		            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		        }
		        xmlhttp.onreadystatechange = function() {
		            if (this.readyState == 4 && this.status == 200) {
		                document.getElementById("txtHint").innerHTML = this.responseText;
		            }
		        };
		        xmlhttp.open("GET","data.php?q="+str,true);
		        xmlhttp.send();
		    
		}
// function to update , marke review and move to next question
		function update_qid_review(str) {
		    	


		    	 
					var id = str -1 ;
		    	if(document.getElementById('submit'+id).className == "grid-class1" || document.getElementById('submit'+id).className == "grid-class3" )
		    	{
		    		document.getElementById('submit'+id).className = "grid-class2"	
		    	}
		    	else{
		    		document.getElementById('submit'+id).className = "grid-class1"
		    	}


		        if (window.XMLHttpRequest) {
		            // code for IE7+, Firefox, Chrome, Opera, Safari
		            xmlhttp = new XMLHttpRequest();
		        } else {
		            // code for IE6, IE5
		            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		        }
		        xmlhttp.onreadystatechange = function() {
		            if (this.readyState == 4 && this.status == 200) {
		                document.getElementById("txtHint").innerHTML = this.responseText;
		            }
		        };
		        xmlhttp.open("GET","data.php?q="+str,true);
		        xmlhttp.send();
		    
		}
// function to update , marke submit and move to next question

	function update_qid_submit(str) {
		    	


			    	 
					var id = str -1 ;
		    		document.getElementById('submit'+id).className = "grid-class3"	
		    	


		        if (window.XMLHttpRequest) {
		            // code for IE7+, Firefox, Chrome, Opera, Safari
		            xmlhttp = new XMLHttpRequest();
		        } else {
		            // code for IE6, IE5
		            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		        }
		        xmlhttp.onreadystatechange = function() {
		            if (this.readyState == 4 && this.status == 200) {
		                document.getElementById("txtHint").innerHTML = this.responseText;
		            }
		        };
		        xmlhttp.open("GET","data.php?q="+str,true);
		        xmlhttp.send();
		    
		}
// function to marke option as submitted for user to as user visit previous submitted or marked questios


		function update_option_submit(obj){

			var kids = document.getElementById('option_menu').children;
			for (var i = 0; i < kids.length ; i++) {
				kids[i].className = "option";
			}
			obj.className = "option_selected";


		}
		 function foo(obj){

			
			var kids = document.getElementById('option_menu').children;
			for (var i = 0; i < kids.length ; i++) {
				kids[i].className = "option";
			}

			kids[obj-1].className = "option_selected";

		}		
