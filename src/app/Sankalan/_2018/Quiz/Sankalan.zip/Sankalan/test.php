 	<?php 
	include 'includes/connect.php';
	session_start();

//	if($_POST["selectedevent"] != "select") {
		//$selectedevent = $_SESSION["event-id"];
		$selectedevent = "algoholics";
		$_SESSION["event-id"] = $selectedevent;

		$event_name = $selectedevent;
		$selectedevent = strtolower($selectedevent);
		
		$sql = "select qid 
				from $selectedevent ORDER BY RAND()
				limit 5";
		$result = $conn->query($sql);
		$resulttemp = $result;
		$userscore = 0;
		$qno = 0;
	//}	
		$qid_array = array(4,1,2,3,5);
		$_SESSION["ques-array"] = $qid_array;
		$ans_array = array(2,1,0,0,0);
		$_SESSION["answ-array"] = $ans_array;
		
		
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>Event Quiz</title>	
	<link href="https://fonts.googleapis.com/css?family=Share+Tech" rel="stylesheet"> 
	<link rel="stylesheet" href="maintest.css">
	<script src="main.js"></script>
		<style>
		body{
			font-family: 'Share Tech', sans-serif;
		}
	</style>
	
</head>
<body>

	<header >
		<div class="container title">
			
			<div id="branding">
				<h2  id="navbar"><span class="highlight">Sankalan</span> 2018</h2>
			</div>	
			<nav>
				<ul>
					
		
					<li class="counter"><strong>Timer: </strong><input type="text" size="8" name="d2"><br/><br/></li>
					<li class="current"><a href="result.html"> LogOut </a></li>
					
				</ul>
			</nav>
		</div>
	</header>
	<main id="main">
		<div class="grid2">
			<div id="section-b" class="header">
				<div class="nested">
					<div class="ques-header">
						<div class="event-head">
							<h2><?php echo $event_name; ?> Quiz</h2>
						</div>
					</div>
					<div class="ques-grid">
						<h2>Grid</h2>
						<div class="ques-grid-inside">
						
							<button type="submit"  class="grid-class1" id="submit1" onclick="update_qid(1);"> 1 </button>
							<button type="submit" class="grid-class1" id="submit2"  onclick="update_qid(2);" > 2 </button>
							<button type="submit" class="grid-class1" id="submit3" onclick="update_qid(3);" > 3 </button>
							<button type="submit" class="grid-class1" id="submit4" onclick="update_qid(4);" > 4 </button>
							<button type="submit" class="grid-class1" id="submit5" onclick="update_qid(5);" > 5 </button>
							<button type="submit" class="grid-class1" id="submit6" onclick="update_qid(6);" > 6 </button>
							<button type="submit" class="grid-class1" id="submit7" onclick="update_qid(7);" > 7 </button>
							<button type="submit" class="grid-class1" id="submit8" onclick="update_qid(8);" > 8 </button>
							<button type="submit" class="grid-class1" id="submit9" onclick="update_qid(9);" > 9 </button>
							<button type="submit" class="grid-class1" id="submit10" onclick="update_qid(10);" > 10 </button>
							<button type="submit" class="grid-class1" id="submit11" onclick="update_qid(11);" > 11 </button>
							<button type="submit" class="grid-class1" id="submit12" onclick="update_qid(12);" > 12 </button>
							<button type="submit" class="grid-class1" id="submit13" onclick="update_qid(13);" > 13 </button>
							<button type="submit" class="grid-class1" id="submit14" onclick="update_qid(14);" > 14 </button>
							<button type="submit" class="grid-class1" id="submit15" onclick="update_qid(15);" > 15 </button>
							<button type="submit" class="grid-class1" id="submit16" onclick="update_qid(16);" > 16 </button>
							<button type="submit" class="grid-class1" id="submit17" onclick="update_qid(17);" > 17 </button>
							<button type="submit" class="grid-class1" id="submit18" onclick="update_qid(18);" > 18 </button>
							<button type="submit" class="grid-class1" id="submit19" onclick="update_qid(19);" > 19 </button>
							<button type="submit" class="grid-class1" id="submit20" onclick="update_qid(20);" > 20 </button>
							<button type="submit" class="grid-class1" id="submit21" onclick="update_qid(21);" > 21 </button>
							<button type="submit" class="grid-class1" id="submit22" onclick="update_qid(22);" > 22 </button>
							<button type="submit" class="grid-class1" id="submit23" onclick="update_qid(23);" > 23 </button>
							<button type="submit" class="grid-class1" id="submit24" onclick="update_qid(24);" > 24 </button>
							<button type="submit" class="grid-class1" id="submit25" onclick="update_qid(25);" > 25 </button>
							<button type="submit" class="grid-class1" id="submit26" onclick="update_qid(26);" > 26 </button>
							<button type="submit" class="grid-class1" id="submit27" onclick="update_qid(27);" > 27 </button>
							<button type="submit" class="grid-class1" id="submit28" onclick="update_qid(28);" > 28 </button>
							<button type="submit" class="grid-class1" id="submit29" onclick="update_qid(29);" > 29 </button>
							<button type="submit" class="grid-class1" id="submit30" onclick="update_qid(30);" > 30 </button>
						
						</div>
					</div>
					
					<div class="ques-disp" id="txtHint">
						<div class="event-ques" >
							<?php
								$ans = 0;
								$sql = "select qid,question, a, b, c, d 
								from $selectedevent 
								where qid = $qid_array[0]";
								$result1 = $conn->query($sql);
								$row = mysqli_fetch_array($result1);
								echo "a ".$row["qid"]."   $ans_array[0]

								<h3 onload='foo(".$ans_array[0].");' class='ques' id='ques-area'> Q.1 ".$row["question"]." ?</h3>
								<script>
									function getvalue(){
										var v = document.getElementByName('ques-option');
										if(v[0].checked)
										{
											".$ans." = 1;
										}
										else if(v[1].checked)
										{
											".$ans." = 2;
										}
										else if(v[2].checked)
										{
											".$ans." = 3;
										}
										else if(v[3].checked)
										{
											".$ans." = 4;
										}
								}
								</script>
							<h6> $ans 
								<ol id='option_menu'   >
									<li class='option op1' id='opp1' onclick='update_option_submit(this);' ><input type='radio' name='ques-option' value = 'a' onclick=' getvalue();'>  ".$row["a"]."</input></li>
									<li class='option op2' id='opp2' onclick='update_option_submit(this);'><input type='radio' name='ques-option' value = 'b' onclick=' getvalue();'>  ".$row["b"]."  </input></li>
									<li class='option op3' id='opp3' onclick='update_option_submit(this);'><input type='radio' name='ques-option' value = 'c' onclick=' getvalue();' >  ".$row["c"]."  </input></li>
									<li class='option op4' id='opp4' onclick='update_option_submit(this);'><input type='radio' name='ques-option' value = 'd' onclick=' getvalue();' >  ".$row["d"]."  </input></li>
								</ol>
							</h6>
							</div>
							<div class='nav'>
								<button type='submit' onclick='update_qid(2); ' class='prev' > Skip </button>
								<button type='submit' onclick='update_qid_review(2);' class='next'> Mark For Review </button>
								<button type='submit' onclick='update_qid_submit(2);' class='submit-all'> Submit  </button>
												
							</div>";
						?>


					</div>
					
				</div>
			</div>
			<div id="section-e" class="footer">

				<footer id="main-footer" >
					<div>
						<p>Sankalan 2018 </p>
					</div>
					<div> <p>Something to be written</p>
					</div>
					<div class="copyright">
						<p>© Copyright 2018. All Rights Reserved | Sankalan | Annual Tech-Fest | Department of Computer Science </p>
					</div>
				</footer>
			</div>
		</div>
	</main>
	
</body>
</html>