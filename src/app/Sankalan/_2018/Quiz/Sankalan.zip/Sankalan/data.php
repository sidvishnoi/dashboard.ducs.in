<?php
session_start();
		include 'includes/connect.php';

	$selectedevent = $_SESSION["event-id"];
	$qid_array = $_SESSION["ques-array"];
	//}	
	$ans = 0 ;
	$ans_array = $_SESSION["answ-array"];		
	$n = intval($_GET['q'])-1;
	$sql = "select * 
	from $selectedevent 
	where qid = $qid_array[$n]";
	$result1 = $conn->query($sql);
	$row = mysqli_fetch_array($result1);
	echo "b $n ".$row["qid"]."  $ans_array[$n]

	<h3 class='ques'>Q.".($n+1)." ".$row["question"]." ?</h3>
		<script>
			function getvalue(){
				var v = document.getElementByName('ques-option');
				if(v[0].checked)
				{
					".$ans." = 1;
				}
				else if(v[1].checked)
				{
					".$ans." = 2;
				}
				else if(v[2].checked)
				{
					".$ans." = 3;
				}
				else if(v[3].checked)
				{
					".$ans." = 4;
				}
		}
		</script>
	<h6> $ans 
		<ol id='option_menu'   >
			<li class='option op1' id='opp1' onclick='update_option_submit(this);' ><input type='radio' name='ques-option' onclick=' getvalue(); ' value = 'a'  >  ".$row["a"]."</input></li>
			<li class='option op2' id='opp2' onclick='update_option_submit(this);'><input type='radio' name='ques-option'  onclick=' getvalue(); ' value = 'b'  >  ".$row["b"]."  </input></li>
			<li class='option op3' id='opp3' onclick='update_option_submit(this);'><input type='radio' name='ques-option'  onclick=' getvalue(); ' value = 'c'   >  ".$row["c"]."  </input></li>
			<li class='option op4' id='opp4' onclick='update_option_submit(this);'><input type='radio' name='ques-option'  onclick=' getvalue(); ' value = 'd'   >  ".$row["d"]."  </input></li>
		</ol>
	</h6>
	</div>
	<div class='nav'>
		<button type='submit' onclick='update_qid(".($n+2)."); ' class='prev' > Skip </button>
		<button type='submit' onclick='update_qid_review(".($n+2).");' class='next'> Mark For Review </button>
		<button type='submit' onclick='update_qid_submit(".($n+2).");' class='submit-all'> Submit  </button>
						
	</div>";
?>


			