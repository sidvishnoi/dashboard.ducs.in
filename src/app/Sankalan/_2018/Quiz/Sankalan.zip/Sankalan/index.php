<?php 
	include 'includes/connect.php';
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>Sankalan 2018</title>	
	<link href="https://fonts.googleapis.com/css?family=Share+Tech" rel="stylesheet"> 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="main1.css">
	<script type="text/javascript" src="main.js"></script>
	<style>
		body{
			font-family: 'Share Tech', sans-serif;
		}
	</style>
</head>
<body>

	<header >
		<div class="container title">
			
			<div id="branding">
				<h2  id="navbar"><span class="highlight">Sankalan</span> 2018</h2>
			</div>	
			<nav>
				<ul>
					<li class="current"><a href="index.html">Home</a></li>
					<li><a href="aboutus.html">About</a></li>
					<li><a href="contactus.html">Contact</a></li>
				</ul>
			</nav>
		</div>
	</header>
	<main id="main">
		<div class="grid">
			<div id="section-a" class="title">
				
				<h1>Sankalan</h1>
				<h3>Quiz Portal</h3>
				<form action="#section-c" id="form-login">
					<button type="submit">LogIn For Event..</button>
				</form>
				
				<form action="#" id="form-register">
					<button type="submit">Register For Event..</button>
				</form>

				<form action="#section-d" id="form-event">
					<button type="submit">Click For Event Info..</button>
				</form>
				

			</div>
			<div id="section-b" class="header">
				<h2>Rules :</h2>
				<ul>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
					<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, ea.</li>
				</ul>
			</div>
			<div id="section-c" class="sidebar"><div class="container">
				<h1>Login..</h1>
				<form action="verification.php" method="post" id="section-c-form" >
					<input type="text" name="username" placeholder="Enter Team id...">
					<input type="password" name="password" placeholder="Enter Password...">
					<select name="selectedevent" id="">
						<option value="select"> Select </option>
					<?php 
							$sql = "select * from events ";
							$result = $conn->query($sql);

							//echo "<option value='none'>None</option>";
							while($row = $result->fetch_assoc()) {
		        				echo "<option value=".$row['eventid'].">".$row['eventname']."</option>";
		    				} 
					?>
					</select>
					<button action="submit" class="button_1">Log In</button>
				</form>
			</div></div>
			<div id="section-d" class="content">
				<h1>Sankalan Events Details</h1>
					<div id="slideshow">
					   
					</div>
			</div>
			<div id="section-e" class="footer">
				<div class="nested">
					<div class="box">
							<h2 class="content-title">Contact Us</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione nesciunt vitae, omnis deserunt eum vel quo dignissimos maxime neque reiciendis.</p>
							<p>Sankalan2018@gmail.com</p>

					</div>
					<div class="box1">
							<h2 class="content-title">About Our Fest</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla tempore, id. Quam laborum harum quo nam hic nobis veritatis perferendis accusamus, dolor debitis, alias doloremque modi nisi quia minus animi!</p>
						
					</div>
				</div>
				<footer id="main-footer" >
					<div>
						<p>Sankalan 2018 </p>
						<p>Our Website:<a href="#" target="_blank">Redirect To Website</a></p>
					</div>
					<div class="copyright">
						<p>© Copyright 2018. All Rights Reserved | Sankalan | Annual Tech-Fest | Department of Computer Science </p>
					</div>
				</footer>
			</div>
		</div>
	</main>
	
</body>
</html>